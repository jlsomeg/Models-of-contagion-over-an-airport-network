	package gui;

import java.awt.EventQueue;
import java.awt.FileDialog;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import tools.Contagion;
import tools.ModeloSIR;
import tools.ModeloSIS;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FilenameFilter;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;

public class Gui {

	private JFrame frame;
	private FileDialog openNodeFile;
	private FileDialog openEdgeFile;
	private FileDialog outputFile;
	private JTextField tfdNode;
	private JTextField tfdEdge;
	private JTextField tfdInferccion;
	private JTextField tfdRecuperacion;
	private JTextField tfdIteracion;
	private JTextField tfdRepAleatorio;
	private JTextField tfdCuarentena;
	private JTextField tfdGradoCuarentena;
	private String Modo = "SI / SIS";
	private String outputDirectory;
	private String outputName;
	private JTextField tfdOutputFile;
	private boolean SM = false;
	private boolean BG = false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui window = new Gui();
					window.frame.setTitle("Contagion Simulator");
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Gui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		openNodeFile = new FileDialog(new JFrame(), "open", FileDialog.LOAD);
		openEdgeFile = new FileDialog(new JFrame(), "open", FileDialog.LOAD);
		outputFile = new FileDialog(new JFrame(), "save", FileDialog.SAVE);
		outputFile.setFilenameFilter(new FilenameFilter(){
			public boolean accept(File dir, String name) {
				return name.endsWith(".txt");
			}
		});
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 520);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNode = new JLabel("Fichero de Nodos");
		lblNode.setBounds(24, 30, 102, 18);
		frame.getContentPane().add(lblNode);
		
		tfdNode = new JTextField();
		tfdNode.setBounds(201, 27, 113, 24);
		frame.getContentPane().add(tfdNode);
		tfdNode.setColumns(10);
		tfdNode.setEditable(false);
		
		JButton btnChooseNodeFile = new JButton("Seleccionar");
		btnChooseNodeFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openNodeFile.setVisible(true);
				if (openNodeFile.getDirectory() != null && openNodeFile.getFile() != null) {
					tfdNode.setText(openNodeFile.getDirectory() + openNodeFile.getFile());
				}
			}
		});
		btnChooseNodeFile.setBounds(328, 26, 122, 27);
		frame.getContentPane().add(btnChooseNodeFile);
		
		JLabel lblEdge = new JLabel("Fichero de Aristas");
		lblEdge.setBounds(24, 61, 126, 18);
		frame.getContentPane().add(lblEdge);
		
		tfdEdge = new JTextField();
		tfdEdge.setColumns(10);
		tfdEdge.setBounds(201, 58, 113, 24);
		frame.getContentPane().add(tfdEdge);
		tfdEdge.setEditable(false);
		
		JButton btnChooseEdgeFile = new JButton("Seleccionar");
		btnChooseEdgeFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openEdgeFile.setVisible(true);
				if (openEdgeFile.getDirectory() != null && openEdgeFile.getFile() != null) {
					tfdEdge.setText(openEdgeFile.getDirectory() + openEdgeFile.getFile());
				}
			}
		});
		btnChooseEdgeFile.setBounds(328, 57, 122, 27);
		frame.getContentPane().add(btnChooseEdgeFile);
		
		JLabel lblInferccion = new JLabel("Tasa de Infeccion (%)");
		lblInferccion.setBounds(24, 92, 162, 18);
		frame.getContentPane().add(lblInferccion);
		
		tfdInferccion = new JTextField();
		tfdInferccion.setColumns(10);
		tfdInferccion.setBounds(200, 89, 114, 24);
		frame.getContentPane().add(tfdInferccion);
		
		JLabel lblRecuperacion = new JLabel("Tasa de Recuperacion (%)");
		lblRecuperacion.setBounds(24, 123, 162, 18);
		frame.getContentPane().add(lblRecuperacion);
		
		tfdRecuperacion = new JTextField();
		tfdRecuperacion.setColumns(10);
		tfdRecuperacion.setBounds(200, 120, 114, 24);
		frame.getContentPane().add(tfdRecuperacion);
		
		JLabel lblIteracion = new JLabel("N. de Iteraciones");
		lblIteracion.setBounds(24, 154, 122, 18);
		frame.getContentPane().add(lblIteracion);
		
		tfdIteracion = new JTextField();
		tfdIteracion.setBounds(200, 151, 114, 24);
		frame.getContentPane().add(tfdIteracion);
		tfdIteracion.setColumns(10);
		
		JLabel lblAleatorio = new JLabel("Random Walks?");
		lblAleatorio.setBounds(24, 185, 162, 18);
		frame.getContentPane().add(lblAleatorio);
		
		JCheckBox cbAleatorio = new JCheckBox("");
		cbAleatorio.setBounds(201, 184, 45, 27);
		frame.getContentPane().add(cbAleatorio);
		
		JLabel lblRepAleatorio = new JLabel("Frec. de los RW");
		lblRepAleatorio.setBounds(24, 216, 122, 18);
		frame.getContentPane().add(lblRepAleatorio);
		
		tfdRepAleatorio = new JTextField();
		tfdRepAleatorio.setBounds(200, 213, 114, 24);
		frame.getContentPane().add(tfdRepAleatorio);
		tfdRepAleatorio.setColumns(10);
		
		JLabel lblModoEspecial = new JLabel("Modo Especial?");
		lblModoEspecial.setBounds(24, 247, 162, 18);
		frame.getContentPane().add(lblModoEspecial);
		
		JCheckBox cbModoEspecial = new JCheckBox("");
		cbModoEspecial.setBounds(201, 243, 45, 27);
		frame.getContentPane().add(cbModoEspecial);
		
		JLabel lblCuarentena = new JLabel("Cuarentena (%)");
		lblCuarentena.setBounds(24, 278, 122, 18);
		frame.getContentPane().add(lblCuarentena);
		
		tfdCuarentena = new JTextField();
		tfdCuarentena.setColumns(10);
		tfdCuarentena.setBounds(200, 275, 114, 24);
		frame.getContentPane().add(tfdCuarentena);
		
		JLabel lblGradoCuarentena = new JLabel("Grado Cuarentena");
		lblGradoCuarentena.setBounds(24, 309, 144, 18);
		frame.getContentPane().add(lblGradoCuarentena);
		
		tfdGradoCuarentena = new JTextField();
		tfdGradoCuarentena.setColumns(10);
		tfdGradoCuarentena.setBounds(200, 306, 114, 24);
		frame.getContentPane().add(tfdGradoCuarentena);
				
		JComboBox<String> ModeloComboBox = new JComboBox<String>();
		ModeloComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() != ItemEvent.SELECTED){
					Modo = ModeloComboBox.getSelectedItem().toString();
				}
			}
			
		});
		ModeloComboBox.setBounds(328, 97, 122, 24);
		ModeloComboBox.addItem("SI / SIS");
		ModeloComboBox.addItem("SIR");
		frame.getContentPane().add(ModeloComboBox);
		
		JLabel lblOutputFile = new JLabel("Fichero de salida ");
		lblOutputFile.setBounds(24, 340, 144, 18);
		frame.getContentPane().add(lblOutputFile);
		
		JLabel lblElPrimerNodo = new JLabel("El 1.er nodo infectado debe tener:");
		lblElPrimerNodo.setBounds(24, 371, 192, 18);
		frame.getContentPane().add(lblElPrimerNodo);
		
		tfdOutputFile = new JTextField();
		tfdOutputFile.setEditable(false);
		tfdOutputFile.setColumns(10);
		tfdOutputFile.setBounds(201, 337, 113, 24);
		frame.getContentPane().add(tfdOutputFile);
		
		JButton btnChooseOutput = new JButton("Seleccionar");
		btnChooseOutput.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				outputFile.setVisible(true);
				if(outputFile.getDirectory() != null && outputFile.getFile() != null) {
					outputName = outputFile.getFile() + ".csv";
					outputDirectory = outputFile.getDirectory();
					tfdOutputFile.setText(outputDirectory + outputName);
				}
			}
			
		});
		btnChooseOutput.setBounds(328, 336, 122, 27);
		frame.getContentPane().add(btnChooseOutput);
		
		JRadioButton rdbtnHubsPequeo = new JRadioButton("Grado Bajo (<6)");
		rdbtnHubsPequeo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SM = true;
				BG = false;
			}
		});
		rdbtnHubsPequeo.setBounds(29, 398, 122, 27);
		frame.getContentPane().add(rdbtnHubsPequeo);
		
		JRadioButton rdbtnHubsGrande = new JRadioButton("Grado Alto (>170)");
		rdbtnHubsGrande.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SM = false;
				BG = true;
			}
		});
		rdbtnHubsGrande.setBounds(29, 437, 142, 27);
		frame.getContentPane().add(rdbtnHubsGrande);
		
		JRadioButton rdbtnAleatorio = new JRadioButton("Cualquier Grado");
		rdbtnAleatorio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SM = false;
				BG = false;
			}
		});
		rdbtnAleatorio.setBounds(196, 398, 157, 27);
		frame.getContentPane().add(rdbtnAleatorio);
		
		ButtonGroup infectedOptionGroup = new ButtonGroup();
		infectedOptionGroup.add(rdbtnHubsPequeo);
		infectedOptionGroup.add(rdbtnHubsGrande);
		infectedOptionGroup.add(rdbtnAleatorio);
		
		JButton btnCrear = new JButton("Crear");
		btnCrear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double rate_i = Double.parseDouble(tfdInferccion.getText());
				double rate_r = Double.parseDouble(tfdRecuperacion.getText());
				int iter = Integer.parseInt(tfdIteracion.getText());
				boolean rw = cbAleatorio.isSelected();
				int rw_frq = Integer.parseInt(tfdRepAleatorio.getText());;
				boolean ch = cbModoEspecial.isSelected();
				double quarantine = Double.parseDouble(tfdCuarentena.getText());
				int grados_qua = Integer.parseInt(tfdGradoCuarentena.getText());
				
				Contagion cont;
				
				System.out.println("Modelo " + Modo);
				if(Modo.equals("SI / SIS")){
					cont = new ModeloSIS(rate_i, rate_r, tfdNode.getText(), tfdEdge.getText());
				} else {
					cont = new ModeloSIR(rate_i, rate_r, tfdNode.getText(), tfdEdge.getText());
				}
				
				cont.doAll(iter, rw, rw_frq, ch, quarantine, grados_qua, SM, BG, outputDirectory, outputName);
				System.out.println("finish!");
				new JOptionPane();
				JOptionPane.showMessageDialog(new JFrame(), "finish!");
			}
		});
		
		btnCrear.setBounds(355, 429, 113, 27);
		frame.getContentPane().add(btnCrear);
	}
}
