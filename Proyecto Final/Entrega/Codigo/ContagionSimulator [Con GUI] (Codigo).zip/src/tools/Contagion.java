package tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;

public abstract class Contagion {
	protected HashMap<String, Nodo> nodos;	// Collection of nodes
	protected ArrayList<String> hubs;
	protected int infected;					// Number of infected nodes
	protected int healthy;					// Number of healthy nodes
	protected double infectionRate;			// Infection Rate
	protected double recoveryRate;			// Recovery Rate
	protected String nodeFile;
	protected String edgeFile;
	protected ArrayList<String> bigHubs;
	protected ArrayList<String> smallHubs;
	
	public Contagion(double rate, double reco, String nodeFile, String edgeFile) {
		this.infected = 0;
		this.healthy = 0;
		this.infectionRate = rate;
		this.recoveryRate = reco;
		this.nodos = new HashMap<String,Nodo>();
		this.hubs = new ArrayList<String>();
		this.nodeFile = nodeFile;
		this.edgeFile = edgeFile;
		this.bigHubs = new ArrayList<String>();
		this.smallHubs = new ArrayList<String>();
	}
	
	public abstract void doAll(int iter, boolean RW, int RW_F, boolean cheats,
			double Q, int grad_q, boolean SM, boolean BG, String directory, String fileName);
	
	/*** Inicializacion de Nuestra Red ***/
	protected void initializeCollection() {
		try{
			BufferedReader reader = new BufferedReader(new FileReader(nodeFile));
			String line = reader.readLine();
			while((line = reader.readLine()) != null){
				String[] parts = line.split(";");
				nodos.put(parts[0], new Nodo(parts[0]));
				healthy++;
			}
			reader.close();
		} catch(IOException e){
			// WAT
		}
	}
	
	protected void initializeRelations() {
		try{
			BufferedReader reader = new BufferedReader(new FileReader(edgeFile));
			String line = reader.readLine();
			line = reader.readLine();
			while(line != null){
				String[] parts = line.split(";");
				Nodo one = addingFriends(parts[0], parts[1]);
				Nodo two = addingFriends(parts[1], parts[0]);
				nodos.put(parts[0], one);
				nodos.put(parts[1], two);
				
				if(one.getFriendsSize() > 170 && !bigHubs.contains(one.getId())){ 
					bigHubs.add(one.getId());
				}
				
				line = reader.readLine();
			}
			reader.close();
		} catch(IOException e){
			// WAT
		}
	}
	
	protected void InitQuarantineList(int grad_q){
		for(Entry<String,Nodo> entry : nodos.entrySet()){
			if(entry.getValue().getFriendsSize() > grad_q){
				hubs.add(entry.getKey());
			}
		}
	}
	
	protected void ActivateQuarantine() {
		for(int i = 0; i < hubs.size(); i++){
			if(!nodos.get(hubs.get(i)).isInfected() && !nodos.get(hubs.get(i)).isRecovered()) {
				Nodo nodo = nodos.get(hubs.get(i));
				nodo.setInQuarantine(true);
				nodos.put(hubs.get(i), nodo);
				healthy--;
			}
		}
	}
	
	private Nodo addingFriends(String s1, String s2) {
		Nodo node = nodos.get(s1);					
		int pos = node.getFriends().indexOf(s2);	// Buscamos el otro nodo en la lista
		if(pos == -1){								// Si no esta en su lista de amigos ...
			node.addFriend(s2);						// ... Nos aseguramos de incluirlo
		}
		return node;
	}
	
	/*** Primer Contagio ***/
	protected void pickUnfortunate(ArrayList<String> left){
		List<String> keys;
		if(left == null){
			keys = new ArrayList<String>(nodos.keySet());
		} else {
			keys = left;
		}
		Random rn = new Random();
		int ran = rn.nextInt(keys.size());
		String id = keys.get(ran);
		
		Nodo node = nodos.get(id);
		if(!node.isInfected() && !node.isInQuarantine()){
			node.setInfected(true);
			nodos.put(id, node);
			infected++;
			healthy--;
		}
	}
	
	protected boolean chance(boolean inf){
		boolean ok = false;
		Random rand = new Random();
		int chance = rand.nextInt(1000);
		double res = (double)chance/(double)1000;
		if(inf && res < infectionRate){
			ok = true;
		} else if(!inf && res < recoveryRate){
			ok = true;
		}
		return ok;
	}
	
	/*** Resto del Mundo ***/
	
	protected void transmission(){
		HashMap<String,Nodo> aux = deepCopy();
		for (Entry<String, Nodo> entry : aux.entrySet()) {		// Iteramos sobre la copia de la lista
		    String id = entry.getKey();							// Obtenemos el id DEL MAPA AUXILIAR
		    Nodo node = aux.get(id);							// Obtenemos el nodo asociado DEL MAPA AUXILIAR
		    if(node.isInfected()){								// Si el NODO AUXILIAR esta infectado
		    	node = nodos.get(id);							// Si lo es, entonces actuamos sobre el NODO ORIGINAL	
		    	ArrayList<String> friends = node.getFriends();	// Obtenemos los vecinos del NODO ORIGINAL
		    	for(int i = 0; i < friends.size(); i++){		// Iteramos sobre sus vecinos
		    		Nodo friend = nodos.get(friends.get(i));	// Obtenemos uno de los vecinos
		    		if(chance(true) && !friend.isInQuarantine() 
		    				&& !friend.isRecovered() && !friend.isInfected()){	// Infectamos si no lo esta
		    			friend.setInfected(true);				// Infectamos el vecino
		    			nodos.put(friends.get(i), friend);		// Lo volvemos a colocar en el mapa
		    			infected++;								// Actualizamos la poblacion	
		    			healthy--;
		    		}
		    	}
		    }
		}
	}
	
	protected abstract void recovery();
	
	protected HashMap<String, Nodo> deepCopy()
	{
	    HashMap<String, Nodo> copy = new HashMap<String, Nodo>();
	    for (Map.Entry<String, Nodo> entry : nodos.entrySet())
	    {
	    	Nodo node = new Nodo(entry.getKey());
	    	node.setInfected(entry.getValue().isInfected());
	    	for(int i = 0; i < entry.getValue().getFriends().size(); i++){
	    		node.addFriend(entry.getValue().getFriends().get(i));
	    	}
	        copy.put(entry.getKey(),node);
	    }
	    return copy;
	}
	
	protected abstract void printResults(BufferedWriter writer, int time);
	
	protected abstract void printStatus(int i);

	protected void createFolder(String folderName){
		File file = new File(folderName);
		if(!file.exists()){
			file.mkdir();
		} else {
			String[]entries = file.list();
			for(String s: entries){
			    File currentFile = new File(file.getPath(),s);
			    currentFile.delete();
			}
		}
	}

	protected void smallHubs(){
		for(Entry <String, Nodo> entry : nodos.entrySet()){
			if(entry.getValue().getFriendsSize() < 6)
				smallHubs.add(entry.getKey());
			if(smallHubs.size() > 50)
				break;
		}
	}

}
