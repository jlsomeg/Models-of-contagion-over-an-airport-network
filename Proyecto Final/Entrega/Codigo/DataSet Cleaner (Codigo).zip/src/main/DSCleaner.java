package main;

import tools.DataPolisher;
import tools.DataSetCleaner;
import tools.DuplicateRemover;

public class DSCleaner {

	public static void main(String[] args) {
		DataSetCleaner ds = new DataSetCleaner();
		DataPolisher dt = new DataPolisher();
		DuplicateRemover dr = new DuplicateRemover();
		ds.doAll();
		dt.doAll();
		dr.doAll();
	}

}
