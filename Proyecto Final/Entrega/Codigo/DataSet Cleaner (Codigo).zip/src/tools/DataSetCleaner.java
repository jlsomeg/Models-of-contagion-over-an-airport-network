package tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class DataSetCleaner {

	private ArrayList<String> nodos;
	private ArrayList<String> edges;
	private ArrayList<String> edges_UN;
	
	public DataSetCleaner(){
		nodos = new ArrayList<String>();
		edges = new ArrayList<String>();
		edges_UN = new ArrayList<String>();
	}
	
	public void doAll(){
		cleanNodesData();
		cleanEdgesData();
	}
	
	private void cleanNodesData(){
		BufferedReader br = null;
		try {
			String sCurrentLine;
			br = new BufferedReader(new FileReader("airports.dat"));
			while ((sCurrentLine = br.readLine()) != null) {
				String nodo = "";
				String[] tags = sCurrentLine.split(",");
				
				if(tags.length == 12){
					nodo = tags[0] + ";" + tags[2] + ";" + tags[6] + ";" + tags[7];
				} else if (tags.length == 11){
					nodo = tags[0] + ";" + tags[2] + ";" + tags[5] + ";" + tags[6];
				} else if (tags.length == 10){
					nodo = tags[0] + ";" + tags[2] + ";" + tags[4] + ";" + tags[5];
				}
				nodos.add(nodo);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		nodesToCsv("Aeropuertos_Nodos.csv");
	}
	
	private void cleanEdgesData(){
		BufferedReader br = null;
		try {
			String sCurrentLine;
			br = new BufferedReader(new FileReader("routes.dat"));
			while ((sCurrentLine = br.readLine()) != null) {
				String nodo = "";
				String[] tags = sCurrentLine.split(",");
				int value1 = convertToNumber(tags[3]);
				int value2 = convertToNumber(tags[5]);
				if(value1 == -1 || value2 == -1){
					// DO NOTHING
				} else {
					nodo = tags[3] + ";" + tags[5];
					edges.add(nodo + ";Directed");
					edges_UN.add(nodo + ";Undirected");
				}
			}
			br.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		edgesToCsv("Enlaces (Dirigidos).csv");
		edgesUNToCsv("Enlaces (Sin Pesos).csv");
	}
	
	private int convertToNumber(String id){
		try
	    {
	      int i = Integer.parseInt(id);
	      return i;
	    }
	    catch (NumberFormatException nfe)
	    {
	      // DO NOTHING
	    }
		return -1;
	}
	
	private void nodesToCsv(String fileName) {
		try{
			BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
			bw.write("id;label;Latitude;Longitude" + "\r\n");
			for(int i = 0; i < nodos.size(); i++){
				bw.write(nodos.get(i) + "\r\n");
			}
			bw.close();
		} catch (IOException e){
			System.out.println("Error Writing Nodes");
		}
	}
	
	private void edgesToCsv(String fileName) {
		try{
			BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
			bw.write("source;target;type" + "\r\n");
			for(int i = 0; i < edges.size(); i++){
				bw.write(edges.get(i) + "\r\n");
			}
			bw.close();
		} catch (IOException e){
			System.out.println("Error Writing Edges 1");
		}
	}
	
	private void edgesUNToCsv(String fileName) {
		try{
			BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
			bw.write("source;target;type" + "\r\n");
			for(int i = 0; i < edges_UN.size(); i++){
				bw.write(edges_UN.get(i) + "\r\n");
			}
			bw.close();
		} catch (IOException e){
			System.out.println("Error Writing Edges 2");
		}
	}
}
