package tools;

public class Nodo {
	private String label;
	private String latitud;
	private String longitude;
	
	public Nodo(String lab, String lat, String lon){
		this.label = lab;
		this.latitud = lat;
		this.longitude = lon;
	}

	public String getLabel() {
		return label;
	}

	public String getLatitud() {
		return latitud;
	}

	public String getLongitude() {
		return longitude;
	}
	
}
