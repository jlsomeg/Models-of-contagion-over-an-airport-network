package tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map.Entry;

public class DuplicateRemover {
	HashMap<String, Integer> clean;
	
	public void doAll(){
		clean = new HashMap<String, Integer>();
		readDataset();
		writeDataset();
	}
	
	private void readDataset(){
		try {
			BufferedReader reader = new BufferedReader(new FileReader("Enlaces (Sin Pesos).csv"));
			String enlace = reader.readLine();
			while((enlace = reader.readLine()) != null){
				String[] parts = enlace.split(";");
				String line;
				
				String line1 = parts[0] + ";" + parts[1] + ";" + parts[2];
				String line2 = parts[1] + ";" + parts[0] + ";" + parts[2];
				
				if(!clean.containsKey(line1) && !clean.containsKey(line2)){
					clean.put(enlace, 1);
				} else {
					if (clean.containsKey(line1)){
						line = line1;
					} else {
						line = line2;
					}
					int peso = clean.get(line);
					peso++;
					clean.put(line, peso);
				} 
			}			
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void writeDataset(){
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter("Enlaces.csv"));
			writer.write("source;target;type;weight" + "\r\n");
			for(Entry<String, Integer> entry : clean.entrySet()){
				writer.write(entry.getKey() + ";" + entry.getValue() + "\r\n");
			}
			writer.close();
			//deleteFile("Enlaces (Dirigidos).txt");
			//deleteFile("Enlaces (Sin Pesos).txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
