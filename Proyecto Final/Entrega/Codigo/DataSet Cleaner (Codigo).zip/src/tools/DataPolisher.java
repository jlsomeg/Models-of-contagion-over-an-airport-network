package tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

public class DataPolisher {
	private HashMap<Integer,Nodo> Nodos;
	private HashMap<Integer,String> Edges;
	
	public DataPolisher(){
		Nodos = new HashMap<Integer,Nodo>();
		Edges = new HashMap<Integer,String>();
	}
	
	public void doAll(){
		readNodes();
		readEdges();
		writeFinalVersion();
	}
	
	private void readNodes(){	
		try{
			BufferedReader reader = new BufferedReader(new FileReader("Aeropuertos_Nodos.csv"));
			String line = reader.readLine();
			line = reader.readLine();
			while(line != null){
				try{
					String[] parts = line.split(";");				
					int id = Integer.parseInt(parts[0]);
					Nodo Nodo = new Nodo(parts[1],parts[2],parts[3]);
					Nodos.put(id, Nodo);
				} catch (NumberFormatException ex){
					// WAT
				}
				line = reader.readLine();
			}
			reader.close();
			deleteFile("Aeropuertos_Nodos.csv");
		} catch (IOException e){
			// WAT
		}
	}
	
	private void deleteFile(String fileName){
		try{
    		File file = new File(fileName);
    		file.delete();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
	}
	
	private void readEdges(){
		try{
			BufferedReader reader = new BufferedReader(new FileReader("Enlaces (Sin Pesos).csv"));
			String line = reader.readLine();
			line = reader.readLine();
			while(line != null){
				try{
					String[] parts = line.split(";");				
					Edges.put(Integer.parseInt(parts[0]), "");
					Edges.put(Integer.parseInt(parts[1]), "");
				} catch (NumberFormatException ex){
					// WAT
				}
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e){
			// WAT
		}
	}
	
	private void writeFinalVersion(){
		try {
			BufferedWriter bW = new BufferedWriter(new FileWriter(new File("Nodos.csv")));
			bW.write("id;label;Latitude;Longitude;status" + "\r\n");
			Iterator <Integer> it = Nodos.keySet().iterator();
			Integer clave = null;
			while(it.hasNext()){
				clave = it.next();
				if(Edges.containsKey(clave)){
					Nodo n = Nodos.get(clave);
					String line = clave + ";" + n.getLabel() + ";" + n.getLatitud() + ";" + n.getLongitude() + ";healthy";
					bW.write(line + "\r\n");
					System.out.println(line);
				}
			}
			bW.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
