package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import tools.Contagion;
import tools.ModeloSIR;
import tools.ModeloSIS;

public class ContagionSimulator {

	public static void main(String[] args) {
			
		try {
			
			BufferedReader reader = new BufferedReader(new FileReader("input.txt"));
			File dir = new File("Evoluci�n");
			dir.mkdir();
			String aux;
			String directory = dir.getAbsolutePath();
			int i = 1;
			while((aux = reader.readLine()) != null){
				
				String[] rates = aux.split(",");
				double rate_i = Double.parseDouble(rates[0]);
				double rate_r = Double.parseDouble(rates[1]);
				int iter = Integer.parseInt(rates[2]);
				boolean rw = rates[3].equals("True");
				int rw_frq = Integer.parseInt(rates[4]);
				boolean ch = rates[5].equals("True");
				double quarantine = Double.parseDouble(rates[6]);
				int grados_qua = Integer.parseInt(rates[7]);
				boolean SM = rates[8].equals("True");
				boolean BG = rates[9].equals("True");
				String mode =  rates[10];

				Contagion cont;
				if(mode.equals("SIS") || mode.equals("SI")){
					cont = new ModeloSIS(rate_i, rate_r, "Nodos.csv", "Enlaces.csv");
				} else {
					cont = new ModeloSIR(rate_i, rate_r, "Nodos.csv", "Enlaces.csv");
				}

				cont.doAll(iter, rw, rw_frq, ch, quarantine, grados_qua, SM, BG, directory, "Evoluci�n N.� " + i + ".csv");
				i++;
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}

}
