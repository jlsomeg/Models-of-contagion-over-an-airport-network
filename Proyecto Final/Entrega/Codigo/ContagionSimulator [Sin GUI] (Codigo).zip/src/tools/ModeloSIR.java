package tools;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map.Entry;

public class ModeloSIR extends Contagion {
	private int recovered;					// Number of recovered/dead nodes

	public ModeloSIR(double rate, double reco, String nodeFile, String edgeFile){
		super(rate, reco, nodeFile, edgeFile);
		this.recovered = 0;
	}
	
	public void doAll(int iter, boolean RW, int RW_F, boolean cheats,
			double Q, int grad_q, boolean SM, boolean BG, String directory, String fileName){
		try {
			initializeCollection();
			initializeRelations();
			InitQuarantineList(grad_q);
			smallHubs();
			int time = 0;
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(directory + "\\" + fileName));
			writer.write("time;healthy;infected;recovered" + "\r\n");
			printResults(writer, time);
			time++;
			
			if(BG){
				pickUnfortunate(bigHubs);
			} else if (SM) {
				pickUnfortunate(smallHubs);
			} else {
				pickUnfortunate(null);
			}

			printResults(writer, time);
			
			while(((healthy > 0 || recovered > 0) && infected > 0) && time < iter){
				time++;
				
				transmission();
				recovery();
				
				if(RW && time%RW_F == 0  && (RW_F>0)){
					if(cheats){
						pickUnfortunate(availableNodes());
					} else {
						pickUnfortunate(null);
					}
				}
				
				double porc = (double)healthy/(healthy+infected);
				if(Q > 0 && Q > porc){
					ActivateQuarantine();
					Q = 0;
				}
								
				printResults(writer, time);
				
				// debug stuff
				System.out.println(infected + " - " + healthy + " - " + recovered);
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	protected void recovery(){
		for (Entry<String, Nodo> entry : nodos.entrySet()) {		
		    String id = entry.getKey();							
		    Nodo node = nodos.get(id);							
		    if(node.isInfected() && chance(false)){				
		    	node = nodos.get(id);
		    	node.setInfected(false);
		    	node.setRecovered(true);
		    	nodos.put(id, node);
    			infected--;										
    			recovered++;
		    }
		}
	}
	
	private ArrayList<String> availableNodes(){
		ArrayList<String> left = new ArrayList<String>();
		for(Entry<String, Nodo> entry : nodos.entrySet()){
			Nodo node = entry.getValue();
			if(!node.isInfected() && !node.isRecovered()){
				left.add(node.getId());
			}
		}
		return left;
	}
		
	protected void printResults(BufferedWriter writer, int time){
		double total = healthy+infected+recovered;
		double per_i = (double)infected/total;
		double per_h = (double)healthy/total;
		double per_r = (double)recovered/total;
		try {
			writer.write(time + ";" + per_h + ";" + per_i + ";" + per_r + "\r\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
}
