package tools;

import java.util.ArrayList;

public class Nodo {
	private String id;
	private boolean infected;
	private boolean recovered;
	private boolean InQuarantine;
	private ArrayList<String> friends;
	
	public Nodo(String id){
		this.id = id;
		this.infected = false;
		this.recovered = false;
		this.InQuarantine = false;
		this.friends = new ArrayList<String>();
	}

	public boolean isInfected() {
		return infected;
	}

	public void setInfected(boolean infected) {
		this.infected = infected;
	}

	public String getId() {
		return id;
	}

	public ArrayList<String> getFriends() {
		return friends;
	}
	
	public void addFriend(String f){
		this.friends.add(f);
	}
	
	public boolean isInQuarantine() {
		return InQuarantine;
	}

	public void setInQuarantine(boolean inQuarantine) {
		InQuarantine = inQuarantine;
	}
	
	public boolean isRecovered() {
		return recovered;
	}

	public void setRecovered(boolean infected) {
		this.recovered = infected;
	}
	
	public int getFriendsSize() {
		return this.friends.size();
	}
	
}
